uploaddialog = function()
{
  document.getElementById("uploaddialog").style.display="block";
} 
